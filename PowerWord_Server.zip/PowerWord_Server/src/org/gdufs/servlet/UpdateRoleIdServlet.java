package org.gdufs.servlet;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.gdufs.dao.RoleDao;
import org.gdufs.entity.Role;

/**
 * Servlet implementation class UpdateRoleIdServlet
 */
@WebServlet("/UpdateRoleIdServlet")
public class UpdateRoleIdServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 RoleDao dao = new RoleDao();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateRoleIdServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String str ;
		try {
			Role role = null;
			ObjectInputStream ios = null;
			ios = new ObjectInputStream(request.getInputStream());
			DataOutputStream oos = null;
			oos = new DataOutputStream(response.getOutputStream());
			role =  (Role)ios.readObject();
			System.out.println(role.getUserName());								
			if (dao.updateRoleId(role)) {
				str ="success";//�ɹ�
			}else{
				 str ="fail";
			}				
			oos.writeUTF(str);
			
			oos.flush();
			oos.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
		
		}
	}

}
