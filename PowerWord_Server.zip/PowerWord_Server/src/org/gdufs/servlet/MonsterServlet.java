package org.gdufs.servlet;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.gdufs.dao.JuniorDao;
import org.gdufs.dao.MonsterDao;
import org.gdufs.entity.Junior;
import org.gdufs.entity.Monster;

/**
 * Servlet implementation class MonsterServlet
 */
@WebServlet("/MonsterServlet")
public class MonsterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private JuniorDao juniorDao = new JuniorDao();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MonsterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Junior monster = null;
			//DataInputStream ios = null;
			//ios = new DataInputStream(request.getInputStream());
			ObjectOutputStream oos = null;
			oos = new ObjectOutputStream(response.getOutputStream());
			monster = this.juniorDao.RandomLoad();
			if (monster  != null) {
				oos.writeObject(monster );
			} else {
				oos.writeObject(monster);//�쳣������ʧ��
			}
			oos.flush();
			oos.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
		}
	}

}
