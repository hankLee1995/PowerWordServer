package org.gdufs.servlet;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.gdufs.dao.RoleDao;
import org.gdufs.entity.Role;

/**
 * Servlet implementation class LoadRoleServlet
 */
@WebServlet("/LoadRoleServlet")
public class LoadRoleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private RoleDao roleDao = new RoleDao();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoadRoleServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Role role = null;
			DataInputStream ios = null;
			ios = new DataInputStream(request.getInputStream());
			ObjectOutputStream oos = null;
			oos = new ObjectOutputStream(response.getOutputStream());
			String username =  ios.readUTF();
			role = this.roleDao.findRoleByName(username);
			System.out.println(username);
			if (role != null) {
				oos.writeObject(role);
			} else {
				role = new Role();
				role.setUserName("fail");
				oos.writeObject(role);
			}
			oos.flush();
			oos.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
		}
	}

}
