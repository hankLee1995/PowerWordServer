package org.gdufs.servlet;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.gdufs.dao.JuniorDao;
import org.gdufs.entity.Junior;

/**
 * Servlet implementation class JuniorServlet
 */
@WebServlet("/JuniorServlet")
public class JuniorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private JuniorDao juniorDao = new JuniorDao();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public JuniorServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Junior junior = this.juniorDao.findJuniorById(3);
		if(junior!=null)
		response.getWriter().print(junior.getCha()+" "+junior.getEng());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Junior junior = null;
			DataInputStream ios = null;
			ios = new DataInputStream(request.getInputStream());
			ObjectOutputStream oos = null;
			oos = new ObjectOutputStream(response.getOutputStream());
			int WordId =  ios.readInt();
			System.out.println(WordId);
			junior = this.juniorDao.findJuniorById(WordId);
			if (junior != null) {
				oos.writeObject(junior);
			} else {
				junior = new Junior();
				junior.setWordId(0);//�����ڸ�id�ĵ���
				oos.writeObject(junior);
			}
			oos.flush();
			oos.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
		}
	}

}
