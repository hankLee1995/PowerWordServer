package org.gdufs.servlet;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.gdufs.dao.DailyDao;
import org.gdufs.entity.Daily;

/**
 * Servlet implementation class DailyServlet
 */
@WebServlet("/DailyServlet")
public class DailyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private DailyDao dailyDao = new DailyDao();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DailyServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Daily daily = null;
			DataInputStream ios = null;
			ios = new DataInputStream(request.getInputStream());
			ObjectOutputStream oos = null;
			oos = new ObjectOutputStream(response.getOutputStream());
			int WordId =  ios.readInt();
			daily = this.dailyDao.findDailyById(WordId);
			if (daily != null) {
				oos.writeObject(daily);
			} else {
				daily = new Daily();
				daily.setWordId(0);//�����ڸ�id�ĵ���
				oos.writeObject(daily);
			}
			oos.flush();
			oos.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
		}
	}

}
