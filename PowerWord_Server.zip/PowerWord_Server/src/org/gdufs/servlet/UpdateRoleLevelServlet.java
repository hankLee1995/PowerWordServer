package org.gdufs.servlet;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.gdufs.dao.RoleDao;
import org.gdufs.entity.Role;
import org.gdufs.entity.User;

/**
 * Servlet implementation class UpdateRoleLevelServlet
 */
@WebServlet("/UpdateRoleLevelServlet")
public class UpdateRoleLevelServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
     RoleDao dao = new RoleDao();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateRoleLevelServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String str ;
		try {
			Role role = null;
			ObjectInputStream ios = null;
			ios = new ObjectInputStream(request.getInputStream());
			DataOutputStream oos = null;
			oos = new DataOutputStream(response.getOutputStream());
			role =  (Role)ios.readObject();
			System.out.println(role.getUserName()+"���½�ɫ���飺"+role.getExp());								
			if (dao.updateRoleLevel(role)) {
				str ="success";//ע��ɹ�
			}else{
				 str ="fail";
			}				
			oos.writeUTF(str);
			
			oos.flush();
			oos.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
		}
	}

}
