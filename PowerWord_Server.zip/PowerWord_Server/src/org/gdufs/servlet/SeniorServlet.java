package org.gdufs.servlet;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.gdufs.dao.SeniorDao;
import org.gdufs.entity.Senior;

/**
 * Servlet implementation class SeniorServlet
 */
@WebServlet("/SeniorServlet")
public class SeniorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private SeniorDao seniorDao = new SeniorDao();   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SeniorServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Senior senior = null;
			DataInputStream ios = null;
			ios = new DataInputStream(request.getInputStream());
			ObjectOutputStream oos = null;
			oos = new ObjectOutputStream(response.getOutputStream());
			int WordId =  ios.readInt();
			senior = this.seniorDao.findSeniorById(WordId);
			if (senior != null) {
				oos.writeObject(senior);
			} else {
				senior = new Senior();
				senior.setWordId(0);//�����ڸ�id�ĵ���
				oos.writeObject(senior);
			}
			oos.flush();
			oos.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
		}
	}

}
