package org.gdufs.servlet;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.gdufs.dao.RoleDao;
import org.gdufs.entity.Role;

/**
 * Servlet implementation class LoadRankServlet
 */
@WebServlet("/LoadRankServlet")
public class LoadRankServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private RoleDao roleDao = new RoleDao();  
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoadRankServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			List<Role> role = new ArrayList<>();
			ObjectOutputStream oos = null;
			oos = new ObjectOutputStream(response.getOutputStream());
			role = this.roleDao.LoadRoleRank();
			System.out.println("--load_rank--");
			
		   oos.writeObject(role);
			oos.flush();
			oos.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
		}
		
	}

}
