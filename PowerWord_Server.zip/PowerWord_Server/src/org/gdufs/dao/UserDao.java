package org.gdufs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.gdufs.entity.User;
import org.gdufs.util.DBHelper;

public class UserDao {
	
	public boolean insertUser(User user) {
		int rows = 0;
		Connection con = null;
		PreparedStatement stat = null;
		con = DBHelper.connect();
		try {
			String sql = "insert into user (UserName ,Pwd ,Photo,Sex ,Phone,Email) values (?,?,?,?,?,?)";
			stat = con.prepareStatement(sql);
			stat.setString(1, user.getUserName());
			stat.setString(2, user.getPwd());
			stat.setString(3, user.getPhoto());
			stat.setString(4, user.getSex());
			stat.setString(5, user.getPhone());
			stat.setString(6, user.getEmail());

			rows = stat.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
			return false;
		} finally {
			DBHelper.closePreparedStatement(stat);
			DBHelper.closeConneciton(con);
		}
		if( rows>0 ){
			return true;
		}else{
			return false;
		}
	}
	
	public boolean updateUser(User user) {
		int rows = 0;
		Connection con = null;
		PreparedStatement stat = null;
		con = DBHelper.connect();
		try {
			String sql = "update user set Pwd=? ,Photo=?,Sex=? ,Phone=?,Email=? where UserName=?";
			stat = con.prepareStatement(sql);
			stat.setString(1, user.getPwd());
			stat.setString(2, user.getPhoto());
			stat.setString(3, user.getSex());
			stat.setString(4, user.getPhone());
			stat.setString(5, user.getEmail());
			stat.setString(6, user.getUserName());
			rows = stat.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
			return false;
		} finally {
			DBHelper.closePreparedStatement(stat);
			DBHelper.closeConneciton(con);
		}
		if( rows>0)
			return true;
		else
			return false;
	}
	
	public User findUserByName(String UserName) {
		User user = null;
		Connection con = null;
		PreparedStatement stat = null;
		con = DBHelper.connect();
//		System.out.println("con:"+con);
		String sql1 = "select * from user where UserName=?";// and password=?";
		try {
			stat = con.prepareStatement(sql1);
			stat.setString(1, UserName);
			ResultSet rs = stat.executeQuery();
			if (rs.next()) {
				user = new User();
				user.setUserName(UserName);
				user.setPwd(rs.getString("Pwd"));
				user.setPhoto(rs.getString("Photo"));
				user.setSex(rs.getString("Sex"));
				user.setPhone(rs.getString("Phone"));
				user.setEmail(rs.getString("Email"));				
			}
		} catch (SQLException ex) {
			System.out.println("dao�쳣"+ex.toString());
		} finally {
			DBHelper.closePreparedStatement(stat);
			DBHelper.closeConneciton(con);
		}
		return user;
	}
}
