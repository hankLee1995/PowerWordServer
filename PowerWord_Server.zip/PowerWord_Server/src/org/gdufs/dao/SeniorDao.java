package org.gdufs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.gdufs.entity.Senior;
import org.gdufs.util.DBHelper;

public class SeniorDao {
		
	public Senior findSeniorById(int WordId) {
		Senior senior = null;
		Connection con = null;
		PreparedStatement stat = null;
		con = DBHelper.connect();
//		System.out.println("con:"+con);
		String sql1 = "select * from senior where WordId=?";// and password=?";
		try {
			stat = con.prepareStatement(sql1);
			stat.setInt(1, WordId);
			ResultSet rs = stat.executeQuery();
			if (rs.next()) {
				senior = new Senior();
				senior.setWordId(WordId);
				senior.setEng(rs.getString("Eng"));	
				senior.setCha(rs.getString("Cha"));	
				//senior.setPron(rs.getString("Pron"));	
			}
		} catch (SQLException ex) {
			System.out.println("dao�쳣"+ex.toString());
		} finally {
			DBHelper.closePreparedStatement(stat);
			DBHelper.closeConneciton(con);
		}
		return senior;
	}
}
