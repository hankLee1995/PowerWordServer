package org.gdufs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.gdufs.entity.Junior;
import org.gdufs.util.DBHelper;

public class JuniorDao {

	public Junior findJuniorById(int WordId) {
		Junior junior = null;
		Connection con = null;
		PreparedStatement stat = null;
		con = DBHelper.connect();
//		System.out.println("con:"+con);
		String sql1 = "select * from junior where WordId=?";// and password=?";
		try {
			stat = con.prepareStatement(sql1);
			stat.setInt(1, WordId);
			ResultSet rs = stat.executeQuery();
			if (rs.next()) {
				junior = new Junior();
				junior.setWordId(WordId);
				junior.setEng(rs.getString("Eng"));	
				junior.setCha(rs.getString("Cha"));	
				//senior.setPron(rs.getString("Pron"));	
			}
		} catch (SQLException ex) {
			System.out.println("dao�쳣"+ex.toString());
		} finally {
			DBHelper.closePreparedStatement(stat);
			DBHelper.closeConneciton(con);
		}
		return junior;
	}
	
	public Junior RandomLoad() {
		Junior junior = null;
		Connection con = null;
		PreparedStatement stat = null;
		con = DBHelper.connect();
		int i = (int) (Math.random()*4000)+2;
		String sql1 = "select * from junior where WordId=?";// and password=?";
		try {
			stat = con.prepareStatement(sql1);
			stat.setInt(1, i);
			ResultSet rs = stat.executeQuery();
			if (rs.next()) {
				junior = new Junior();
				junior.setWordId(i);
				junior.setEng(rs.getString("Eng"));	
				junior.setCha(rs.getString("Cha"));	
				//senior.setPron(rs.getString("Pron"));	
			}
		} catch (SQLException ex) {
			System.out.println("dao�쳣"+ex.toString());
		} finally {
			DBHelper.closePreparedStatement(stat);
			DBHelper.closeConneciton(con);
		}
		return junior;
	}
	
}
