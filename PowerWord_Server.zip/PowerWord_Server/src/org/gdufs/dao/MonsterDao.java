package org.gdufs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.gdufs.entity.Monster;
import org.gdufs.util.DBHelper;

public class MonsterDao {
	
	public Monster findMonsterById(int MId) {
		Monster monster = null;
		Connection con = null;
		PreparedStatement stat = null;
		con = DBHelper.connect();
//		System.out.println("con:"+con);
		String sql1 = "select * from monster where MId=?";// and password=?";
		try {
			stat = con.prepareStatement(sql1);
			stat.setInt(1, MId);
			ResultSet rs = stat.executeQuery();
			if (rs.next()) {
				monster = new Monster();
				monster.setEng(rs.getString("Eng"));	
				monster.setCha(rs.getString("Cha"));
				monster.setHP(rs.getInt("HP"));
				//senior.setPron(rs.getString("Pron"));	
			}
		} catch (SQLException ex) {
			System.out.println("dao�쳣"+ex.toString());
		} finally {
			DBHelper.closePreparedStatement(stat);
			DBHelper.closeConneciton(con);
		}
		return monster;
	}
}
