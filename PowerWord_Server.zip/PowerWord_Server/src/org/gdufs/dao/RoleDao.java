package org.gdufs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.gdufs.entity.Role;
import org.gdufs.util.DBHelper;

public class RoleDao {
	
	public int insertRole(Role role) {
		int rows = 0;
		Connection con = null;
		PreparedStatement stat = null;
		con = DBHelper.connect();
		try {
			String sql = "insert into role (UserName ,RoleId ,RoleName) values (?,?,?)";
			stat = con.prepareStatement(sql);
			stat.setString(1, role.getUserName());
			stat.setInt(2, role.getRoleId());
			stat.setString(3, role.getRoleName());
			rows = stat.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			DBHelper.closePreparedStatement(stat);
			DBHelper.closeConneciton(con);
		}
		return rows;
	}
	
	public boolean updateRoleId(Role role) {
		int rows = 0;
		Connection con = null;
		PreparedStatement stat = null;
		con = DBHelper.connect();
		try {
			String sql = "update role set RoleId=? where UserName=?";
			stat = con.prepareStatement(sql);
			stat.setInt(1, role.getRoleId());
			stat.setString(2, role.getUserName());
			rows = stat.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
			return false;
		} finally {
			DBHelper.closePreparedStatement(stat);
			DBHelper.closeConneciton(con);
		}
		if(rows>0)
			return true;
		else
			return false;
		
	}
	
	public boolean updateRoleLevel(Role role) {
		int rows = 0;
		Connection con = null;
		PreparedStatement stat = null;
		con = DBHelper.connect();
		try {
			String sql = "update role set Rank=?,Exp=?,ATK=? ,DEF=?,HP=? where UserName=?";
			stat = con.prepareStatement(sql);
			stat.setInt(1, role.getRank());
			stat.setInt(2, role.getExp());
			stat.setInt(3, role.getATK());
			stat.setInt(4, role.getDEF());
			stat.setInt(5, role.getHP());
			stat.setString(6, role.getUserName());
			rows = stat.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
			return false;
		} finally {
			DBHelper.closePreparedStatement(stat);
			DBHelper.closeConneciton(con);
		}
		if (rows>0)
			return true;
		else
			return false;
	}
	
	public int updateRoleStarvation(Role role) {
		int rows = 0;
		Connection con = null;
		PreparedStatement stat = null;
		con = DBHelper.connect();
		try {
			String sql = "update role set Starvation=? where UserName=?";
			stat = con.prepareStatement(sql);
			stat.setInt(1, role.getStarvation());
			stat.setString(2, role.getUserName());
			rows = stat.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			DBHelper.closePreparedStatement(stat);
			DBHelper.closeConneciton(con);
		}
		return rows;
	}
	
	public Role findRoleByName(String UserName) {
		Role role = null;
		Connection con = null;
		PreparedStatement stat = null;
		con = DBHelper.connect();
//		System.out.println("con:"+con);
		String sql1 = "select * from role where UserName=?";// and password=?";
		try {
			stat = con.prepareStatement(sql1);
			stat.setString(1, UserName);
			ResultSet rs = stat.executeQuery();
			if (rs.next()) {
				role = new Role();
				role.setUserName(UserName);
				role.setRoleId(rs.getInt("RoleId"));
				role.setRoleName(rs.getString("RoleName"));
				role.setExp(rs.getInt("Exp"));
				role.setRank(rs.getInt("Rank"));
				role.setStarvation(rs.getInt("Starvation"));	
				role.setATK(rs.getInt("ATK"));
				role.setDEF(rs.getInt("DEF"));
				role.setHP(rs.getInt("HP"));
			}
		} catch (SQLException ex) {
			System.out.println("dao�쳣"+ex.toString());
		} finally {
			DBHelper.closePreparedStatement(stat);
			DBHelper.closeConneciton(con);
		}
		return role;
	}
	
	public List<Role> LoadRoleRank() {
		List<Role> list = new ArrayList<>();
		Role role =null;
		Connection con = null;
		PreparedStatement stat = null;
		con = DBHelper.connect();
//		System.out.println("con:"+con);
		String sql1 = "select * from role order by Exp ";// and password=?";
		try {
			stat = con.prepareStatement(sql1);			
			ResultSet rs = stat.executeQuery();
			while (rs.next()) {
				role = new Role();
				role.setUserName(rs.getString("UserName"));
				role.setRoleId(rs.getInt("RoleId"));
				role.setRoleName(rs.getString("RoleName"));
				role.setExp(rs.getInt("Exp"));
				role.setRank(rs.getInt("Rank"));
				role.setStarvation(rs.getInt("Starvation"));	
				role.setATK(rs.getInt("ATK"));
				role.setDEF(rs.getInt("DEF"));
				role.setHP(rs.getInt("HP"));
				list.add(role);
			}
		} catch (SQLException ex) {
			System.out.println("dao�쳣"+ex.toString());
		} finally {
			DBHelper.closePreparedStatement(stat);
			DBHelper.closeConneciton(con);
		}
		return list;
	}
}
