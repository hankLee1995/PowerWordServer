package com.example.powerword;

import java.io.DataOutputStream;
import java.io.ObjectInputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.gdufs.entity.Junior;
import org.gdufs.entity.Role;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class Monster_bossFragment extends Fragment{
	private Handler mHandler;
	TextView m1_text,m2_text,m3_text,role_HP,txt_round,sure_txt;
	ImageView m1,m2,m3,my_role;
	EditText my_Eng;
	Button btn_sure;
	String ip = "172.16.225.15";
	String[] answer = new String[4];
	String[] Cha = new String[4];
	boolean[] isKill = new boolean[4];
	int now_id =1;//BOSS��ǰ�ĵ���id
	String data = "";
	int dead = 0;//����������
	int Round =3 ;//�ڼ���
	String HP;		//�̳еĽ�ɫѪ��
    private FragmentManager fragmentManager;
    private FragmentTransaction transaction;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		View view = inflater.inflate(R.layout.fragment_monster_boss, null);
		fragmentManager = this.getFragmentManager();
        Bundle bundle=getArguments();  
        //�ж���д  
        if(bundle!=null)  
        {  
            data=(bundle.getString("username"));  
            HP = (bundle.getString("HP"));
        } 
        sure_txt = (TextView) view.findViewById(R.id.sure_txt);
        txt_round = (TextView) view.findViewById(R.id.txt_round);
		m1_text = (TextView) view.findViewById(R.id.m1_Cha);
		m2_text = (TextView) view.findViewById(R.id.m2_Cha);
		m3_text = (TextView) view.findViewById(R.id.m3_Cha);
		role_HP = (TextView) view.findViewById(R.id.my_role_HP);
		m1 = (ImageView) view.findViewById(R.id.monster1);
		m2 = (ImageView) view.findViewById(R.id.monster2);
		m3 = (ImageView) view.findViewById(R.id.monster3);
		my_role = (ImageView) view.findViewById(R.id.my_role);
		my_Eng = (EditText) view.findViewById(R.id.my_Eng);
		btn_sure = (Button) view.findViewById(R.id.btn_sure);
		
		role_HP.setText("HP:"+HP);
		txt_round.setText("Round 3");
		m2.setImageResource(R.drawable.monster_boss);
		
		//m3.setImageResource(R.drawable.monster6);
		for(int i =0;i<4;i++)//��ʼ��
			isKill[i]=false;
		
		btn_sure.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
						boolean isAttack =false;//�Ƿ���ȷƥ������		
						if((my_Eng.getText().toString()).equals(answer[now_id])){
								killMonster();
								isAttack = true;
								sure_txt.setText("���ι���׼ȷ���е��ˣ�");
							}
						if(isAttack == false)
							sure_txt.setText("��Ӣ�ĶԹ����޷���Ч��");
						if(now_id > 3){
							transaction = fragmentManager.beginTransaction();
					        Fragment sFragment = new SuccessFragment();
				            Bundle bundle4=new Bundle();  
				            bundle4.putString("username",data);
				            String HP = (String) role_HP.getText();
				            bundle4.putString("HP",HP.replace("HP:", ""));
				            sFragment.setArguments(bundle4);
					        transaction.replace(R.id.content, sFragment);
					        transaction.commit();		//������һ��
						}
			}
		});
		
		mHandler = new Handler() {
			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				int i = msg.arg1;
				if(i==4){
					Role role = (Role) msg.obj;
					if(null!=role){
					loadRolePic(role.getRoleId());
					}
				}else{
					Junior jun = (Junior) msg.obj;
					if(null!=jun){
						answer[i] = jun.getEng();
						Cha[i] =jun.getCha();
						switch(i)
						{
							case 1: 
							m2_text.setText(jun.getCha());
							break;
						}
						
					}else{
							m1_text.setText("��������쳣");
							m2_text.setText("��������쳣");
							m3_text.setText("��������쳣");
						}
				}
			}
		};
		
		new Thread(new Runnable() {
			@Override
			public void run() {
				for(int i =1;i<4;i++)
				{
					Junior monster= loadMonster();
					Message msg = Message.obtain();
					msg.obj = monster;
					msg.arg1 = i;
					mHandler.sendMessage(msg);
				}
				
				Role role = loadRole(data);
				Message msg = Message.obtain();
				msg.obj = role;
				msg.arg1 = 4;
				mHandler.sendMessage(msg);
			}
		}).start();
		
		return view;
	}
	
	 public Junior loadMonster() {
			Junior result = null;
			URL url = null;
			try {
				url = new URL("http://" + ip
						+ ":8080/PowerWord_Server/MonsterServlet");
				HttpURLConnection connection = (HttpURLConnection) url
						.openConnection();
				connection.setDoInput(true);
				connection.setDoOutput(true);
				connection.setConnectTimeout(10000);
				connection.setReadTimeout(10000);
				connection.setRequestMethod("POST");// ����Ϊpost����

				ObjectInputStream ois = new ObjectInputStream(
						connection.getInputStream());
				result = (Junior) ois.readObject();
				ois.close();
				connection.disconnect();
			} catch (Exception e) {
				//password.setText(e.toString());
				e.printStackTrace();			
			} finally {

			}
			return result;
		}
	 
	 public Role loadRole(String username) {
			Role result = null;
			URL url = null;
			try {
				url = new URL("http://" + ip
						+ ":8080/PowerWord_Server/LoadRoleServlet");
				HttpURLConnection connection = (HttpURLConnection) url
						.openConnection();
				connection.setDoInput(true);
				connection.setDoOutput(true);
				connection.setConnectTimeout(10000);
				connection.setReadTimeout(10000);
				connection.setRequestMethod("POST");// ����Ϊpost����
				DataOutputStream outobj = new DataOutputStream(
						connection.getOutputStream());
				outobj.writeUTF(username);
				outobj.flush();
				outobj.close();
				ObjectInputStream ois = new ObjectInputStream(
						connection.getInputStream());
				result = (Role) ois.readObject();
				ois.close();
				connection.disconnect();
			} catch (Exception e) {
				//password.setText(e.toString());
				e.printStackTrace();			
			} finally {

			}
			return result;
		}
	 
	 public void loadRolePic(int id){
		 switch(id){
		 	case 0: my_role.setImageResource(R.drawable.role0);break;
		 	case 1: my_role.setImageResource(R.drawable.role1);break;
		 	case 2: my_role.setImageResource(R.drawable.role2);break;
		 	case 3: my_role.setImageResource(R.drawable.role3);break;
		 	case 4: my_role.setImageResource(R.drawable.role4);break;
		 	case 5: my_role.setImageResource(R.drawable.role5);break;
		 	case 6: my_role.setImageResource(R.drawable.role6);break;
		 }
	 }
	 
	 public void killMonster(){
		 now_id++;
		 if(now_id==4){
			 //��ɱ������ѪBOSS����
			 m2.setImageResource(R.drawable.monster_death);
			 return;
		 }
		 if(now_id<4)
			 m2_text.setText(Cha[now_id]);

	 }
}
