package com.example.powerword;

import java.io.ObjectInputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import org.gdufs.entity.Junior;
import org.gdufs.entity.Role;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MainFragment extends Fragment{
	String data="";
	private Handler mHandler;
	TextView rank1,rank2,rank3;
	String ip = "172.16.225.15";
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		View view = inflater.inflate(R.layout.fragment_main, null);
        Bundle bundle=getArguments();  
        //�ж���д  
        if(bundle!=null)  
        {  
            data=(bundle.getString("username"));  
        } 
        rank1 = (TextView) view.findViewById(R.id.rank1);
        rank2 = (TextView) view.findViewById(R.id.rank2);
        rank3 = (TextView) view.findViewById(R.id.rank3);
        
        mHandler = new Handler() {
			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				List<Role> list = (List<Role>)msg.obj;
				if(null!=list)
					for(int i =0;i<3;i++){
						Role r = list.get(i);
						switch(i){
						case 0: rank1.setText(r.getUserName());break;
						case 1: rank2.setText(r.getUserName());break;
						case 2: rank3.setText(r.getUserName());break;
						}
					}
			}
		};
		
		new Thread(new Runnable() {
			@Override
			public void run() {
				List<Role> list = loadRoleList();
				Message msg = Message.obtain();
				msg.obj = list;
				mHandler.sendMessage(msg);
			}
		}).start();
		
		return view;
	}
	
	public List<Role> loadRoleList(){
		List<Role> result = null;
		URL url = null;
		try {
			url = new URL("http://" + ip
					+ ":8080/PowerWord_Server/LoadRankServlet");
			HttpURLConnection connection = (HttpURLConnection) url
					.openConnection();
			connection.setDoInput(true);
			connection.setDoOutput(true);
			connection.setConnectTimeout(10000);
			connection.setReadTimeout(10000);
			connection.setRequestMethod("POST");// ����Ϊpost����

			ObjectInputStream ois = new ObjectInputStream(
					connection.getInputStream());
			result = (List<Role>)ois.readObject();
			ois.close();
			connection.disconnect();
		} catch (Exception e) {
			//password.setText(e.toString());
			e.printStackTrace();			
		} finally {

		}
		return result;
	}
}
