package com.example.powerword;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.Menu;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends FragmentActivity {
	
    Fragment homeFragment;
    Fragment personFragment;
    Fragment sorttypeFragment;
    private FragmentManager fragmentManager;
    private FragmentTransaction transaction;
    int sele_last =0;
    String data = "";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		
		Bundle extras = getIntent().getExtras();
		if (extras != null) {
			data = extras.getString("userid");
		}
		
		fragmentManager = this.getSupportFragmentManager();
        
        transaction = fragmentManager.beginTransaction();
        Fragment fragment = new MainFragment();
        transaction.replace(R.id.content, fragment);
        transaction.commit();
	}
	
	public void clickSele(View target){
		switch(sele_last){
		case 1:   ImageView mImageView = (ImageView)this.findViewById(R.id.ImageView1); 
				  mImageView.setImageResource(R.drawable.juese);break;
				  
		case 2:   mImageView = (ImageView)this.findViewById(R.id.imageView2); 
		  mImageView.setImageResource(R.drawable.danci);break;
		  
		case 3:   mImageView = (ImageView)this.findViewById(R.id.imageView3); 
		  mImageView.setImageResource(R.drawable.renwu);break;
		  
		case 4:   mImageView = (ImageView)this.findViewById(R.id.imageView4); 
		  mImageView.setImageResource(R.drawable.fuben);break;
		  
		case 5:   mImageView = (ImageView)this.findViewById(R.id.imageView5); 
		  mImageView.setImageResource(R.drawable.xinxi);break;
		}
		switch (target.getId()) {
		case R.id.Layout1:
			transaction = fragmentManager.beginTransaction();
            Fragment roleFragment = new RoleInfoFragment();
            Bundle bundle2=new Bundle();  
            bundle2.putString("username",data);
            roleFragment.setArguments(bundle2);
            transaction.replace(R.id.content, roleFragment);
            transaction.commit();
            ImageView mImageView = (ImageView)this.findViewById(R.id.ImageView1); 
            mImageView.setImageResource(R.drawable.juese_sele);
            sele_last =1;
			break;
		case R.id.Layout2:
			transaction = fragmentManager.beginTransaction();
            Fragment wordFragment = new WordFragment();
            transaction.replace(R.id.content, wordFragment);
            transaction.commit();
             mImageView = (ImageView)this.findViewById(R.id.imageView2); 
            mImageView.setImageResource(R.drawable.danci_sele);
            sele_last = 2;
			break;
		case R.id.Layout3:
			transaction = fragmentManager.beginTransaction();
            Fragment dailyFragment = new DailyFragment();
            Bundle bundle3=new Bundle();  
            bundle3.putString("username",data);
            dailyFragment.setArguments(bundle3);
            transaction.replace(R.id.content, dailyFragment);
            transaction.commit();
            mImageView = (ImageView)this.findViewById(R.id.imageView3); 
            mImageView.setImageResource(R.drawable.renwu_sele);
            sele_last =3;
			break;
		case R.id.Layout4:
			transaction = fragmentManager.beginTransaction();
            Fragment monsterFragment = new MonsterFragment();
            Bundle bundle4=new Bundle();  
            bundle4.putString("username",data);
            monsterFragment.setArguments(bundle4);
            transaction.replace(R.id.content, monsterFragment);
            transaction.commit();
            mImageView = (ImageView)this.findViewById(R.id.imageView4); 
            mImageView.setImageResource(R.drawable.fuben_sele);
            sele_last =4;
			break;
		case R.id.Layout5:
			transaction = fragmentManager.beginTransaction();
            Fragment userFragment = new UserInfoFragment();
            Bundle bundle=new Bundle();  
            bundle.putString("username",data);
            userFragment.setArguments(bundle);
            transaction.replace(R.id.content, userFragment);
            transaction.commit();
            mImageView = (ImageView)this.findViewById(R.id.imageView5); 
            mImageView.setImageResource(R.drawable.xinxi_sele);
            sele_last =5;
			break;
    	}
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
