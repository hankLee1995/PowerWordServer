package com.example.powerword;

import java.io.DataInputStream;
import java.io.ObjectOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.gdufs.entity.User;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

public class RegisterActivity extends Activity {
	EditText username, password,phone,email;
	TextView reg_message;
	ImageView photo;
	RadioButton sex_female;
	RadioButton sex_male;
	Button btn_reg;
	Button btn_return;
	Button btn_next;
	String ip = "172.16.225.15";
	private Handler mHandler;
	int last_photo=5;
	int photo_now =1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_register);
		
        username = (EditText) this.findViewById(R.id.reg_username);
		password = (EditText) this.findViewById(R.id.reg_password);
        phone = (EditText) this.findViewById(R.id.reg_phone);
		email = (EditText) this.findViewById(R.id.reg_email);
		reg_message = (TextView) this.findViewById(R.id.reg_message);
		photo = (ImageView) this.findViewById(R.id.reg_photo);
		sex_female = (RadioButton) this.findViewById(R.id.reg_sex_female);
		sex_male = (RadioButton) this.findViewById(R.id.reg_sex_male);
		btn_reg = (Button) this.findViewById(R.id.btn_register);
		btn_return = (Button) this.findViewById(R.id.btn_return);
		btn_next = (Button) this.findViewById(R.id.btn_next);

		mHandler = new Handler() {
			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				int result =  msg.arg1;
				if (result==-1){
					reg_message.setText("�û��������롢�绰����Ϊ��");
				} else if (result<0) {
					reg_message.setText("�û����Ѵ���");
				} else if(result==1){
					reg_message.setText("ע��ɹ���");
					// ����¼�ɹ���ת����һ��activity���������´���
					Intent intent1 = new Intent(RegisterActivity.this,
							LoginActivity.class);
					startActivity(intent1);
				}
			}
		};
		
		btn_reg.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				new Thread(new Runnable() {
					@Override
					public void run() {
						User user = new User();
						user.setUserName(username.getText().toString().trim());
						user.setPwd(password.getText().toString().trim());
						user.setPhoto(String.valueOf(photo_now));
						if(sex_female.isChecked())
							user.setSex("female");
						else
							user.setSex("male");
						user.setPhone(phone.getText().toString().trim());
						user.setEmail(email.getText().toString().trim());
						if(user.getUserName().equals("")||user.getPwd().equals("")||user.getPhone().equals("")){
							Message msg = Message.obtain();
							msg.arg1 = -1;			//0��ʾ�û����������绰��д������
							mHandler.sendMessage(msg);
						}else{
							String re = register(user);
							Message msg = Message.obtain();
							if(re.equals("success")){								
								msg.arg1 = 1;			//�ɹ�
								mHandler.sendMessage(msg);
							}else{
								msg.arg1 = -2;			//ע��������ʧ��
								mHandler.sendMessage(msg);
							}
							
						}

					}
				}).start();

			}
		});
		
		btn_return.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent1 = new Intent(RegisterActivity.this,
						LoginActivity.class);
				startActivity(intent1);
			}
		});
		
		btn_next.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if(photo_now>=last_photo){
					photo_now = 1;					
				}else{
					photo_now++;
				}
				switch(photo_now){
					case 1 :photo.setImageResource(R.drawable.photo1);break;
					case 2 :photo.setImageResource(R.drawable.photo2);break;
					case 3 :photo.setImageResource(R.drawable.photo3);break;
					case 4 :photo.setImageResource(R.drawable.photo4);break;
					case 5 :photo.setImageResource(R.drawable.photo5);break;
					}							
			}
		});
		
	}
	
    public String register(User user) {
		String result = null;
		URL url = null;
		try {
			url = new URL("http://" + ip
					+ ":8080/PowerWord_Server/RegisterServlet");
			HttpURLConnection connection = (HttpURLConnection) url
					.openConnection();
			connection.setDoInput(true);
			connection.setDoOutput(true);
			connection.setConnectTimeout(10000);
			connection.setReadTimeout(10000);
			connection.setRequestMethod("POST");// ����Ϊpost����
			ObjectOutputStream outobj = new ObjectOutputStream(
					connection.getOutputStream());
			outobj.writeObject(user);
			outobj.flush();
			outobj.close();
			DataInputStream ois = new DataInputStream(
					connection.getInputStream());
			result =  ois.readUTF();
			ois.close();
			connection.disconnect();
		} catch (Exception e) {
			//password.setText(e.toString());
			e.printStackTrace();			
		} finally {

		}
		return result;
	}
    
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.register, menu);
		return true;
	}

}
