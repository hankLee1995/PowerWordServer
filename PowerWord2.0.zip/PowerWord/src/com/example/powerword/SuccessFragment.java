package com.example.powerword;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.gdufs.entity.Role;
import org.gdufs.entity.User;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

public class SuccessFragment extends Fragment{
	EditText roleName, Exp;
	TextView update_info,level,level_up,isLevel_up,starvation,starvation_up,
	HP,HP_up,ATK,ATK_up,DEF,DEF_up;
	ImageView photo;
	Button btn_updateRank;
	String ip = "172.16.225.15";
	private Handler mHandler;
	int last_photo=5;
	int photo_now =1;
	String data = "";
	int role_id;
	Role my_role = null;
    private FragmentManager fragmentManager;
    private FragmentTransaction transaction;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		View view = inflater.inflate(R.layout.success, null);
		 fragmentManager = this.getFragmentManager();
        Bundle bundle=getArguments();  
        //�ж���д  
        if(bundle!=null)  
        {  
            data=(bundle.getString("username"));  
        }  
        btn_updateRank = (Button) view.findViewById(R.id.btn_updateRank);
        roleName = (EditText) view.findViewById(R.id.roleName);
		Exp = (EditText) view.findViewById(R.id.Exp);
        level = (TextView) view.findViewById(R.id.level);
        level_up = (TextView) view.findViewById(R.id.level_up);
        isLevel_up = (TextView) view.findViewById(R.id.isLevel_up);
        starvation = (TextView) view.findViewById(R.id.starvation);
        starvation_up = (TextView) view.findViewById(R.id.starvation_up);
        HP = (TextView) view.findViewById(R.id.HP);
        HP_up = (TextView) view.findViewById(R.id.HP_up);
        ATK = (TextView) view.findViewById(R.id.ATK);
        ATK_up = (TextView) view.findViewById(R.id.ATK_up);
        DEF = (TextView) view.findViewById(R.id.DEF);
        DEF_up = (TextView) view.findViewById(R.id.DEF_up);
		update_info = (TextView) view.findViewById(R.id.role_msg);
		photo = (ImageView) view.findViewById(R.id.role_img);
		//btn_return = (Button) view.findViewById(R.id.user_return);

		
		mHandler = new Handler() {
			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				if(msg.arg1==1){
					String re = (String)msg.obj;
					if(re.equals("success")){
						update_info.setText("��ϲ����ɫ��ǿ��");
					}else{
						update_info.setText("��Ǹ�������쳣��");
					}
					return;	
				}
					
				Role role =(Role)msg.obj;
				if (null!=role) {
				   if(role.getRoleName().equals("fail")){
				  		update_info.setText("��δ������ɫ��");
				   }else{
						update_info.setText("���ؽ�ɫ��Ϣ�ɹ�");
						roleName.setText(role.getRoleName());
						Exp.setText(String.valueOf(role.getExp()));
						level.setText(String.valueOf(role.getRank()));
						starvation.setText(String.valueOf(role.getStarvation()));
						HP.setText(String.valueOf(role.getHP()));
						ATK.setText(String.valueOf(role.getATK()));
						DEF.setText(String.valueOf(role.getDEF()));
						role_id = role.getRoleId();
						switch(role_id){
						case 0:photo.setImageResource(R.drawable.role0);break;
						case 1:photo.setImageResource(R.drawable.role1);break;
						case 2:photo.setImageResource(R.drawable.role2);break;
						case 3:photo.setImageResource(R.drawable.role3);break;
						case 4:photo.setImageResource(R.drawable.role4);break;
						case 5:photo.setImageResource(R.drawable.role5);break;
						case 6:photo.setImageResource(R.drawable.role6);break;
						}
						UpRole();
				   }					
				} else{
						   update_info.setText("����ʧ�ܣ�");
					   }
				
			}
		};
		
		new Thread(new Runnable() {
			@Override
			public void run() {
				Role role = loadRole(data);
				Message msg = Message.obtain();
				msg.obj = role;
				mHandler.sendMessage(msg);
				

			}
		}).start();
		
		btn_updateRank.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				new Thread(new Runnable() {
					@Override
					public void run() {
						Message msg2 = Message.obtain();
						msg2.obj = UpdateRoleLevel(my_role);
						msg2.arg1=1;
						mHandler.sendMessage(msg2);
					}
				}).start();
			}
		});
											
		return view;				
	}
	
	 public Role loadRole(String name) {
			
			URL url = null;
			try {
				url = new URL("http://" + ip
						+ ":8080/PowerWord_Server/LoadRoleServlet");
				HttpURLConnection connection = (HttpURLConnection) url
						.openConnection();
				connection.setDoInput(true);
				connection.setDoOutput(true);
				connection.setConnectTimeout(10000);
				connection.setReadTimeout(10000);
				connection.setRequestMethod("POST");// ����Ϊpost����
				DataOutputStream outobj = new DataOutputStream(
						connection.getOutputStream());
				outobj.writeUTF(name);
				outobj.flush();
				outobj.close();
				ObjectInputStream ois = new ObjectInputStream(
						connection.getInputStream());
				my_role = (Role) ois.readObject();
				ois.close();
				connection.disconnect();
			} catch (Exception e) {
				//password.setText(e.toString());
				e.printStackTrace();			
			} finally {

			}
			return my_role;
		}
	 
	 public void UpRole(){
		 my_role.setExp(my_role.getExp()+20);
		 Exp.append("->"+my_role.getExp());
		 if(my_role.getExp()>my_role.getRank()*20){
			 my_role.setRank(my_role.getRank()+1);
			 level_up.setText("->"+my_role.getRank());
			 isLevel_up.setText(" Level Up!");
		 }
		 if(my_role.getStarvation()>0){
			 my_role.setStarvation(my_role.getStarvation()-1);
			 starvation_up.setText("->"+my_role.getStarvation());
		 }
		 my_role.setHP(my_role.getHP()+5);
		 HP_up.setText("->"+my_role.getHP());
		 my_role.setATK(my_role.getATK()+2);
		 ATK_up.setText("->"+my_role.getATK());
		 my_role.setDEF(my_role.getDEF()+2);
		 DEF_up.setText("->"+my_role.getDEF());
	 }
	 
	 public String UpdateRoleLevel(Role role) {
			String result = null;
			URL url = null;
			try {
				url = new URL("http://" + ip
						+ ":8080/PowerWord_Server/UpdateRoleLevelServlet");
				HttpURLConnection connection = (HttpURLConnection) url
						.openConnection();
				connection.setDoInput(true);
				connection.setDoOutput(true);
				connection.setConnectTimeout(10000);
				connection.setReadTimeout(10000);
				connection.setRequestMethod("POST");// ����Ϊpost����
				ObjectOutputStream outobj = new ObjectOutputStream(
						connection.getOutputStream());
				outobj.writeObject(role);
				outobj.flush();
				outobj.close();
				DataInputStream ois = new DataInputStream(
						connection.getInputStream());
				result = ois.readUTF();
				ois.close();
				connection.disconnect();
			} catch (Exception e) {
				//password.setText(e.toString());
				e.printStackTrace();			
			} finally {

			}
			return result;
		}
	
}
