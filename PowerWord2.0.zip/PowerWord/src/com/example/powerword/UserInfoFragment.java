package com.example.powerword;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.gdufs.entity.User;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

public class UserInfoFragment extends Fragment{
	EditText username, password,phone,email;
	TextView update_info;
	ImageView photo;
	RadioButton sex_female;
	RadioButton sex_male;
	Button btn_update;
	Button btn_return;
	Button btn_next;
	String ip = "172.16.225.15";
	private Handler mHandler;
	int last_photo=5;
	int photo_now =1;
	String data = "";
    private FragmentManager fragmentManager;
    private FragmentTransaction transaction;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		View view = inflater.inflate(R.layout.user_info, null);
		 fragmentManager = this.getFragmentManager();
        Bundle bundle=getArguments();  
        //�ж���д  
        if(bundle!=null)  
        {  
            data=(bundle.getString("username"));  
        }  
		
        username = (EditText) view.findViewById(R.id.username);
		password = (EditText) view.findViewById(R.id.password);
        phone = (EditText) view.findViewById(R.id.phone);
		email = (EditText) view.findViewById(R.id.email);
		update_info = (TextView) view.findViewById(R.id.update_info);
		photo = (ImageView) view.findViewById(R.id.photo);
		sex_female = (RadioButton) view.findViewById(R.id.sex_female);
		sex_male = (RadioButton) view.findViewById(R.id.sex_male);
		btn_update = (Button) view.findViewById(R.id.user_update);
		btn_return = (Button) view.findViewById(R.id.user_return);
		btn_next = (Button) view.findViewById(R.id.btn_userphoto);
		
		mHandler = new Handler() {
			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				User user =(User)msg.obj;
				if (null!=user) {
					update_info.setText("�����û���Ϣ�ɹ�");
					username.setText(user.getUserName());
					password.setText(user.getPwd());
					phone.setText(user.getPhone());
					email.setText(user.getEmail());
					if(user.getSex().equals("female"))
						sex_female.setChecked(true);
					else
						sex_male.setChecked(true);
					photo_now = Integer.parseInt(user.getPhoto());
					switch(Integer.parseInt(user.getPhoto())){
					case 1:photo.setImageResource(R.drawable.photo1);break;
					case 2:photo.setImageResource(R.drawable.photo2);break;
					case 3:photo.setImageResource(R.drawable.photo3);break;
					case 4:photo.setImageResource(R.drawable.photo4);break;
					case 5:photo.setImageResource(R.drawable.photo5);break;
					}
					
				} else {
					int result = msg.arg1;
					if(result==-1){
						update_info.setText("����͵绰����д������");
					}else if(result==1){
						update_info.setText("���³ɹ���");
					  	  }else{
					  		update_info.setText("����ʧ�ܣ�");
					  	  }					
				}
			}
		};
		
		new Thread(new Runnable() {
			@Override
			public void run() {
				User user = loadUser(data);
				Message msg = Message.obtain();
				msg.obj = user;
				mHandler.sendMessage(msg);
			}
		}).start();
		
		btn_update.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				new Thread(new Runnable() {
					@Override
					public void run() {
						User user = new User();
						user.setUserName(username.getText().toString().trim());
						user.setPwd(password.getText().toString().trim());
						user.setPhoto(String.valueOf(photo_now));
						if(sex_female.isChecked())
							user.setSex("female");
						else
							user.setSex("male");
						user.setPhone(phone.getText().toString().trim());
						user.setEmail(email.getText().toString().trim());
						if(user.getUserName().equals("")||user.getPwd().equals("")||user.getPhone().equals("")){
							Message msg = Message.obtain();
							msg.arg1 = -1;
							mHandler.sendMessage(msg);
							//0��ʾ�û����������绰��д������							
						}else{
							String re = update(user);
							if(re.equals("success")){
								Message msg = Message.obtain();
								msg.arg1 = 1;
								mHandler.sendMessage(msg);
								 //�ɹ�								
							}else{
								Message msg = Message.obtain();
								msg.arg1 = -2;
								mHandler.sendMessage(msg);
								 //����ʧ��
							}
							
						}

					}
				}).start();

			}
		});
		
		//����ͷ��ť
		btn_next.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if(photo_now>=last_photo){
					photo_now = 1;					
				}else{
					photo_now++;
				}
				switch(photo_now){
					case 1 :photo.setImageResource(R.drawable.photo1);break;
					case 2 :photo.setImageResource(R.drawable.photo2);break;
					case 3 :photo.setImageResource(R.drawable.photo3);break;
					case 4 :photo.setImageResource(R.drawable.photo4);break;
					case 5 :photo.setImageResource(R.drawable.photo5);break;
					}							
			}
		});
		
		btn_return.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				transaction = fragmentManager.beginTransaction();
		        Fragment mainFragment = new MainFragment();
	            Bundle bundle=new Bundle();  
	            bundle.putString("username",data);
	            mainFragment.setArguments(bundle);
		        transaction.replace(R.id.content, mainFragment);
		        transaction.commit();
			}
		});
		
		return view;				
	}
	
	 public User loadUser(String stid) {
			User result = null;
			URL url = null;
			try {
				url = new URL("http://" + ip
						+ ":8080/PowerWord_Server/LoginServlet");
				HttpURLConnection connection = (HttpURLConnection) url
						.openConnection();
				connection.setDoInput(true);
				connection.setDoOutput(true);
				connection.setConnectTimeout(10000);
				connection.setReadTimeout(10000);
				connection.setRequestMethod("POST");// ����Ϊpost����
				DataOutputStream outobj = new DataOutputStream(
						connection.getOutputStream());
				outobj.writeUTF(data);
				outobj.flush();
				outobj.close();
				ObjectInputStream ois = new ObjectInputStream(
						connection.getInputStream());
				result = (User) ois.readObject();
				ois.close();
				connection.disconnect();
			} catch (Exception e) {
				//password.setText(e.toString());
				e.printStackTrace();			
			} finally {

			}
			return result;
		}
	 
	 public String update(User user) {
			String result = null;
			URL url = null;
			try {
				url = new URL("http://" + ip
						+ ":8080/PowerWord_Server/UpdateUserServlet");
				HttpURLConnection connection = (HttpURLConnection) url
						.openConnection();
				connection.setDoInput(true);
				connection.setDoOutput(true);
				connection.setConnectTimeout(10000);
				connection.setReadTimeout(10000);
				connection.setRequestMethod("POST");// ����Ϊpost����
				ObjectOutputStream outobj = new ObjectOutputStream(
						connection.getOutputStream());
				outobj.writeObject(user);
				outobj.flush();
				outobj.close();
				DataInputStream ois = new DataInputStream(
						connection.getInputStream());
				result =  ois.readUTF();
				ois.close();
				connection.disconnect();
			} catch (Exception e) {
				//password.setText(e.toString());
				e.printStackTrace();			
			} finally {

			}
			return result;
		}	 
}
