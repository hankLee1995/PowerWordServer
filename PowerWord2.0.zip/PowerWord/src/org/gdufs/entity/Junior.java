package org.gdufs.entity;

public class Junior implements java.io.Serializable{
	private int WordId;
	private String Eng;
	private String Cha;
	private byte[] Pron;
	public int getWordId() {
		return WordId;
	}
	public void setWordId(int wordId) {
		WordId = wordId;
	}
	public String getEng() {
		return Eng;
	}
	public void setEng(String eng) {
		Eng = eng;
	}
	public String getCha() {
		return Cha;
	}
	public void setCha(String cha) {
		Cha = cha;
	}
	public byte[] getPron() {
		return Pron;
	}
	public void setPron(byte[] pron) {
		Pron = pron;
	}
	
}
