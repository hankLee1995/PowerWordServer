package com.example.powerword;

import java.io.DataOutputStream;
import java.io.ObjectInputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.gdufs.entity.User;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class LoginActivity extends Activity {
	EditText userid, password;
	TextView log_info;
	Button login_ok;
	Button login_reg;
	String ip = "192.168.200.10";
	private Handler mHandler;

     @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        
        userid = (EditText) this.findViewById(R.id.login_userid);
		password = (EditText) this.findViewById(R.id.login_pwd);
		log_info = (TextView) this.findViewById(R.id.login_err);
		login_ok = (Button) this.findViewById(R.id.login_ok);
		login_reg = (Button) this.findViewById(R.id.login_reg);
		mHandler = new Handler() {
			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				User user = (User) msg.obj;
				if (user.getUserName().equals("fail")) {
					log_info.setText("�޴��û�");
				} else if (!user.getPwd().trim()
						.equals(password.getText().toString().trim())) {
					log_info.setText("�����");
				} else {
					log_info.setText("��¼�ɹ���");
					// ����¼�ɹ���ת����һ��activity���������´���
					Bundle bundle = new Bundle();
					bundle.putString("userid", userid.getText().toString());
					Intent intent1 = new Intent(LoginActivity.this,
							MainActivity.class);
					intent1.putExtras(bundle);
					startActivity(intent1);
				}
			}
		};
		
		login_ok.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				new Thread(new Runnable() {
					@Override
					public void run() {
						User user = login(userid.getText().toString()
								.trim());
						Message msg = Message.obtain();
						msg.obj = user;
						mHandler.sendMessage(msg);
					}
				}).start();

			}
		});
		
		login_reg.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent1 = new Intent(LoginActivity.this,
				RegisterActivity.class);
				startActivity(intent1);
			}
		});
    }
    
    public User login(String stid) {
		User result = null;
		URL url = null;
		try {
			url = new URL("http://" + ip
					+ ":8080/PowerWord_Server/LoginServlet");
			HttpURLConnection connection = (HttpURLConnection) url
					.openConnection();
			connection.setDoInput(true);
			connection.setDoOutput(true);
			connection.setConnectTimeout(10000);
			connection.setReadTimeout(10000);
			connection.setRequestMethod("POST");// ����Ϊpost����
			DataOutputStream outobj = new DataOutputStream(
					connection.getOutputStream());
			outobj.writeUTF(this.userid.getText().toString().trim());
			outobj.flush();
			outobj.close();
			ObjectInputStream ois = new ObjectInputStream(
					connection.getInputStream());
			result = (User) ois.readObject();
			ois.close();
			connection.disconnect();
		} catch (Exception e) {
			//password.setText(e.toString());
			e.printStackTrace();			
		} finally {

		}
		return result;
	}


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.login, menu);
        return true;
    }
    
}
