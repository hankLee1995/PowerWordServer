package com.example.powerword;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;


public class DailyFragment extends Fragment{
	Button btn_rem,btn_test;
    private FragmentManager fragmentManager;
    private FragmentTransaction transaction;
    String data="";
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		View view = inflater.inflate(R.layout.fragment_daily, null);
		btn_rem = (Button)view.findViewById(R.id.daily_rem);
		btn_test = (Button)view.findViewById(R.id.btn_register);
	    fragmentManager = this.getFragmentManager();
        Bundle bundle=getArguments();  
        //�ж���д  
        if(bundle!=null)  
        {  
            data=(bundle.getString("username"));  
        }
		btn_rem.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				transaction = fragmentManager.beginTransaction();
		        Fragment dailyFragment = new Daily_remFragment();
	            Bundle bundle1=new Bundle();  
	            bundle1.putString("username",data);
	            dailyFragment.setArguments(bundle1);
		        transaction.replace(R.id.content, dailyFragment);
		        transaction.commit();
			}
		});
		
		btn_test.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				transaction = fragmentManager.beginTransaction();
		        Fragment dailyFragment = new Daily_testFragment();
	            Bundle bundle2=new Bundle();  
	            bundle2.putString("username",data);
	            dailyFragment.setArguments(bundle2);
		        transaction.replace(R.id.content, dailyFragment);
		        transaction.commit();
			}
		});
		
		return view;
	}
	


}
