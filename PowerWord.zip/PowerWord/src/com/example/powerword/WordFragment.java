package com.example.powerword;

import java.io.DataOutputStream;
import java.io.ObjectInputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.gdufs.entity.Junior;
import org.gdufs.entity.User;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class WordFragment extends Fragment{
	private Handler mHandler;
	TextView word_ch,word_en;
	Button btn_last;
	Button btn_next;
	String ip = "192.168.200.10";
	int now_id=1;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		View view = inflater.inflate(R.layout.word_review, null);
		
		word_ch = (TextView) view.findViewById(R.id.ch_tv);
		word_en = (TextView) view.findViewById(R.id.en_tv);
		btn_last = (Button) view.findViewById(R.id.word_last);
		btn_next = (Button) view.findViewById(R.id.word_next);
		
		mHandler = new Handler() {
			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				Junior jun = (Junior) msg.obj;
				if(null!=jun){
					if (jun.getWordId()==0) {
						word_ch.setText("�Ҳ�������");
						word_en.setText("Error");
					}else {
						word_ch.setText(jun.getCha());
						word_en.setText(jun.getEng());
					}
				}else{
					word_ch.setText("�����쳣");
					word_en.setText("Error");
				}
			}
		};
		
		btn_next.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				new Thread(new Runnable() {
					@Override
					public void run() {
						now_id++;
						Junior jun = loadWord(now_id);
						Message msg = Message.obtain();
						msg.obj = jun;
						mHandler.sendMessage(msg);
					}
				}).start();

			}
		});
		
		btn_last.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				new Thread(new Runnable() {
					@Override
					public void run() {
						if(now_id>2){
							now_id--;
							Junior jun = loadWord(now_id);
							Message msg = Message.obtain();
							msg.obj = jun;
							mHandler.sendMessage(msg);
						}
					}
				}).start();

			}
		});
		
		return view;
	}
	
	 public Junior loadWord(int id) {
			Junior result = null;
			URL url = null;
			try {
				url = new URL("http://" + ip
						+ ":8080/PowerWord_Server/JuniorServlet");
				HttpURLConnection connection = (HttpURLConnection) url
						.openConnection();
				connection.setDoInput(true);
				connection.setDoOutput(true);
				connection.setConnectTimeout(10000);
				connection.setReadTimeout(10000);
				connection.setRequestMethod("POST");// ����Ϊpost����
				DataOutputStream outobj = new DataOutputStream(
						connection.getOutputStream());
				outobj.writeInt(id);
				outobj.flush();
				outobj.close();
				ObjectInputStream ois = new ObjectInputStream(
						connection.getInputStream());
				result = (Junior) ois.readObject();
				ois.close();
				connection.disconnect();
			} catch (Exception e) {
				//password.setText(e.toString());
				e.printStackTrace();			
			} finally {

			}
			return result;
		}

}
