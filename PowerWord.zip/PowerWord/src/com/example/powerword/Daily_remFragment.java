package com.example.powerword;

import java.io.DataOutputStream;
import java.io.ObjectInputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.gdufs.entity.Daily;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class Daily_remFragment extends Fragment{
    private FragmentManager fragmentManager;
    private FragmentTransaction transaction;
	private Handler mHandler;
	TextView word_ch,word_en;
	Button btn_last;
	Button btn_next;
	String ip = "192.168.200.10";
	int now_id=1;
	int task_num=5;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		View view = inflater.inflate(R.layout.daily_remember, null);
		word_ch = (TextView) view.findViewById(R.id.daily_rm_ch);
		word_en = (TextView) view.findViewById(R.id.daily_rm_en);
		btn_last = (Button) view.findViewById(R.id.daily_last);
		btn_next = (Button) view.findViewById(R.id.daily_next);
		fragmentManager = this.getFragmentManager();
		mHandler = new Handler() {
			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				Daily daily = (Daily) msg.obj;
				if(null!=daily){
					if (daily.getWordId()==0) {
						word_ch.setText("�Ҳ�������");
						word_en.setText("Error");
					}else if(daily.getWordId()==task_num){
							word_ch.setText(daily.getCha());
							word_en.setText(daily.getEng());
							btn_next.setText("��ɼ���");
						}else{
							word_ch.setText(daily.getCha());
							word_en.setText(daily.getEng());
							btn_next.setText("��һ��");
						}
				}else{
					word_ch.setText("�����쳣");
					word_en.setText("Error");
				}
			}
		};
		
		btn_next.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				new Thread(new Runnable() {
					@Override
					public void run() {
						if(now_id==task_num){
							transaction = fragmentManager.beginTransaction();
					        Fragment dailyFragment = new DailyFragment();
					        transaction.replace(R.id.content, dailyFragment);
					        transaction.commit();
						}
						if(now_id<task_num){
							now_id++;
							Daily daily = loadWord(now_id);
							Message msg = Message.obtain();
							msg.obj = daily;
							mHandler.sendMessage(msg);
						}
					}
				}).start();

			}
		});
		
		btn_last.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				new Thread(new Runnable() {
					@Override
					public void run() {
						if(now_id>1){
							now_id--;
							Daily daily = loadWord(now_id);
							Message msg = Message.obtain();
							msg.obj = daily;
							mHandler.sendMessage(msg);
						}
					}
				}).start();

			}
		});
		return view;				
	}
	
	 public Daily loadWord(int id) {
			Daily result = null;
			URL url = null;
			try {
				url = new URL("http://" + ip
						+ ":8080/PowerWord_Server/DailyServlet");
				HttpURLConnection connection = (HttpURLConnection) url
						.openConnection();
				connection.setDoInput(true);
				connection.setDoOutput(true);
				connection.setConnectTimeout(10000);
				connection.setReadTimeout(10000);
				connection.setRequestMethod("POST");// ����Ϊpost����
				DataOutputStream outobj = new DataOutputStream(
						connection.getOutputStream());
				outobj.writeInt(id);
				outobj.flush();
				outobj.close();
				ObjectInputStream ois = new ObjectInputStream(
						connection.getInputStream());
				result = (Daily) ois.readObject();
				ois.close();
				connection.disconnect();
			} catch (Exception e) {
				//password.setText(e.toString());
				e.printStackTrace();			
			} finally {

			}
			return result;
		}
	
}
