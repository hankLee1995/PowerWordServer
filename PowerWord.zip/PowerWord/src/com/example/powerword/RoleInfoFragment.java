package com.example.powerword;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.gdufs.entity.Daily;
import org.gdufs.entity.Role;
import org.gdufs.entity.User;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

public class RoleInfoFragment extends Fragment{
	EditText roleName, Exp;
	TextView update_info,level,starvation,HP,ATK,DEF;
	ImageView photo;
	Button btn_change,btn_sure;
	String ip = "192.168.200.10";
	private Handler mHandler;
	int last_photo=5;
	int photo_now =1;
	String data = "";
	int role_id;
    private FragmentManager fragmentManager;
    private FragmentTransaction transaction;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		View view = inflater.inflate(R.layout.role_info, null);
		 fragmentManager = this.getFragmentManager();
        Bundle bundle=getArguments();  
        //�ж���д  
        if(bundle!=null)  
        {  
            data=(bundle.getString("username"));  
        }  
		
        btn_change = (Button) view.findViewById(R.id.role_change);
        btn_sure = (Button) view.findViewById(R.id.role_sure);
        roleName = (EditText) view.findViewById(R.id.roleName);
		Exp = (EditText) view.findViewById(R.id.Exp);
        level = (TextView) view.findViewById(R.id.level);
        starvation = (TextView) view.findViewById(R.id.starvation);
        HP = (TextView) view.findViewById(R.id.HP);
        ATK = (TextView) view.findViewById(R.id.ATK);
        DEF = (TextView) view.findViewById(R.id.DEF);
		update_info = (TextView) view.findViewById(R.id.role_msg);
		photo = (ImageView) view.findViewById(R.id.role_img);
		//btn_return = (Button) view.findViewById(R.id.user_return);

		btn_change.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if(role_id<6)
					role_id++;
				else if(role_id==6){
					role_id = 0;
				}
				switch(role_id){
				case 0:photo.setImageResource(R.drawable.role0);break;
				case 1:photo.setImageResource(R.drawable.role1);break;
				case 2:photo.setImageResource(R.drawable.role2);break;
				case 3:photo.setImageResource(R.drawable.role3);break;
				case 4:photo.setImageResource(R.drawable.role4);break;
				case 5:photo.setImageResource(R.drawable.role5);break;
				case 6:photo.setImageResource(R.drawable.role6);break;
				}
			}
		});
		
		btn_sure.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				new Thread(new Runnable() {
					@Override
					public void run() {
						Role role = new Role();
						role.setRoleId(role_id);
						role.setUserName(data);
						Message msg2 = Message.obtain();
						msg2.obj = UpdateRoleId(role);
						msg2.arg1=1;
						mHandler.sendMessage(msg2);
					}
				}).start();

			}
		});
		
		mHandler = new Handler() {
			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				if(msg.arg1==1){
					String re = (String)msg.obj;
					update_info.setText("�����ɫ�ɹ���");
					return;
				}
				Role role =(Role)msg.obj;
				if (null!=role) {
				   if(role.getRoleName().equals("fail")){
				  		update_info.setText("��δ������ɫ��");
				   }else{
						update_info.setText("���ؽ�ɫ��Ϣ�ɹ�");
						roleName.setText(role.getRoleName());
						Exp.setText(String.valueOf(role.getExp()));
						level.setText(String.valueOf(role.getRank()));
						starvation.setText(String.valueOf(role.getStarvation()));
						HP.setText(String.valueOf(role.getHP()));
						ATK.setText(String.valueOf(role.getATK()));
						DEF.setText(String.valueOf(role.getDEF()));
						role_id = role.getRoleId();
						switch(role_id){
						case 0:photo.setImageResource(R.drawable.role0);break;
						case 1:photo.setImageResource(R.drawable.role1);break;
						case 2:photo.setImageResource(R.drawable.role2);break;
						case 3:photo.setImageResource(R.drawable.role3);break;
						case 4:photo.setImageResource(R.drawable.role4);break;
						case 5:photo.setImageResource(R.drawable.role5);break;
						case 6:photo.setImageResource(R.drawable.role6);break;
						}
				   }					
				} else{
						   update_info.setText("����ʧ�ܣ�");
					   }
				
			}
		};
		
		new Thread(new Runnable() {
			@Override
			public void run() {
				Role role = loadRole(data);
				Message msg = Message.obtain();
				msg.obj = role;
				mHandler.sendMessage(msg);
			}
		}).start();
											
		return view;				
	}
	
	 public Role loadRole(String name) {
			Role result = null;
			URL url = null;
			try {
				url = new URL("http://" + ip
						+ ":8080/PowerWord_Server/LoadRoleServlet");
				HttpURLConnection connection = (HttpURLConnection) url
						.openConnection();
				connection.setDoInput(true);
				connection.setDoOutput(true);
				connection.setConnectTimeout(10000);
				connection.setReadTimeout(10000);
				connection.setRequestMethod("POST");// ����Ϊpost����
				DataOutputStream outobj = new DataOutputStream(
						connection.getOutputStream());
				outobj.writeUTF(name);
				outobj.flush();
				outobj.close();
				ObjectInputStream ois = new ObjectInputStream(
						connection.getInputStream());
				result = (Role) ois.readObject();
				ois.close();
				connection.disconnect();
			} catch (Exception e) {
				//password.setText(e.toString());
				e.printStackTrace();			
			} finally {

			}
			return result;
		}
	 
	 public String UpdateRoleId(Role role) {
			String result = null;
			URL url = null;
			try {
				url = new URL("http://" + ip
						+ ":8080/PowerWord_Server/UpdateRoleIdServlet");
				HttpURLConnection connection = (HttpURLConnection) url
						.openConnection();
				connection.setDoInput(true);
				connection.setDoOutput(true);
				connection.setConnectTimeout(10000);
				connection.setReadTimeout(10000);
				connection.setRequestMethod("POST");// ����Ϊpost����
				ObjectOutputStream outobj = new ObjectOutputStream(
						connection.getOutputStream());
				outobj.writeObject(role);
				outobj.flush();
				outobj.close();
				DataInputStream ois = new DataInputStream(
						connection.getInputStream());
				result =  ois.readUTF();
				ois.close();
				connection.disconnect();
			} catch (Exception e) {
				//password.setText(e.toString());
				e.printStackTrace();			
			} finally {

			}
			return result;
		}
	 
	
}
