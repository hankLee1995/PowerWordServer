package org.gdufs.entity;

public class Monster implements java.io.Serializable{
	private int MId;
	private String Eng;
	private String Cha;
	private int HP;
	public int getMId() {
		return MId;
	}
	public void setMId(int mId) {
		MId = mId;
	}
	public String getEng() {
		return Eng;
	}
	public void setEng(String eng) {
		Eng = eng;
	}
	public String getCha() {
		return Cha;
	}
	public void setCha(String cha) {
		Cha = cha;
	}
	public int getHP() {
		return HP;
	}
	public void setHP(int hP) {
		HP = hP;
	}
	
	
}
