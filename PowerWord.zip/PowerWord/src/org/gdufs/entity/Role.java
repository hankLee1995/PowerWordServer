package org.gdufs.entity;

public class Role implements java.io.Serializable{
	private String UserName;
	private int RoleId;
	private String RoleName;
	private int Exp;
	private int Rank;
	private int Starvation;
	private int ATK;
	private int DEF;
	private int HP;
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String username) {
		UserName = username;
	}
	public int getRoleId() {
		return RoleId;
	}
	public void setRoleId(int roleId) {
		RoleId = roleId;
	}
	public String getRoleName() {
		return RoleName;
	}
	public void setRoleName(String roleName) {
		RoleName = roleName;
	}
	public int getExp() {
		return Exp;
	}
	public void setExp(int exp) {
		Exp = exp;
	}
	public int getRank() {
		return Rank;
	}
	public void setRank(int rank) {
		Rank = rank;
	}
	public int getStarvation() {
		return Starvation;
	}
	public void setStarvation(int starvation) {
		Starvation = starvation;
	}
	public int getATK() {
		return ATK;
	}
	public void setATK(int aTK) {
		ATK = aTK;
	}
	public int getDEF() {
		return DEF;
	}
	public void setDEF(int dEF) {
		DEF = dEF;
	}
	public int getHP() {
		return HP;
	}
	public void setHP(int hP) {
		HP = hP;
	}
	
	
}
